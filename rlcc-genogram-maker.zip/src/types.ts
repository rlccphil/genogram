export type Gender = 'male' | 'female' | 'unknown';
export type Status = 'alive' | 'deceased';
export type RelationshipType = 'marriage' | 'unmarried' | 'parent-child';
export type EmotionalDynamic = 'connected' | 'distant' | 'hostile' | 'cutoff';

export interface FamilyMember {
  id: string;
  name: string;
  gender: Gender;
  status: Status;
}

export interface Relationship {
  id: string;
  personA: string;
  personB: string;
  type: RelationshipType;
  dynamic: EmotionalDynamic;
}
