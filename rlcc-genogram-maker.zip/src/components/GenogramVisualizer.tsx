import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { FamilyMember, Relationship } from '../types';

interface GenogramVisualizerProps {
  members: FamilyMember[];
  relationships: Relationship[];
}

const GenogramVisualizer: React.FC<GenogramVisualizerProps> = ({ members, relationships }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || members.length === 0) return;

    const width = 800;
    const height = 600;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const g = svg.append('g');

    // Zoom behavior
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 4])
      .on('zoom', (event) => {
        g.attr('transform', event.transform);
      });

    svg.call(zoom);

    // Simulation
    const simulation = d3.forceSimulation<any>(members)
      .force('link', d3.forceLink<any, any>(relationships)
        .id(d => d.id)
        .distance(100))
      .force('charge', d3.forceManyBody().strength(-300))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide().radius(50));

    // Links
    const link = g.append('g')
      .selectAll('line')
      .data(relationships)
      .enter()
      .append('line')
      .attr('stroke', d => {
        if (d.dynamic === 'hostile') return '#ef4444';
        if (d.dynamic === 'distant') return '#94a3b8';
        if (d.dynamic === 'cutoff') return '#cbd5e1';
        return '#334155';
      })
      .attr('stroke-width', 2)
      .attr('stroke-dasharray', d => {
        if (d.type === 'unmarried' || d.dynamic === 'distant') return '5,5';
        if (d.dynamic === 'cutoff') return '10,5,2,5';
        return 'none';
      });

    // Nodes
    const node = g.append('g')
      .selectAll('g')
      .data(members)
      .enter()
      .append('g')
      .call(d3.drag<any, any>()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended));

    // Shapes based on gender
    node.each(function(d) {
      const el = d3.select(this);
      if (d.gender === 'male') {
        el.append('rect')
          .attr('x', -20)
          .attr('y', -20)
          .attr('width', 40)
          .attr('height', 40)
          .attr('fill', 'white')
          .attr('stroke', '#334155')
          .attr('stroke-width', 2);
      } else if (d.gender === 'female') {
        el.append('circle')
          .attr('r', 20)
          .attr('fill', 'white')
          .attr('stroke', '#334155')
          .attr('stroke-width', 2);
      } else {
        el.append('rect')
          .attr('x', -20)
          .attr('y', -20)
          .attr('width', 40)
          .attr('height', 40)
          .attr('transform', 'rotate(45)')
          .attr('fill', 'white')
          .attr('stroke', '#334155')
          .attr('stroke-width', 2);
      }

      // Deceased 'X'
      if (d.status === 'deceased') {
        el.append('line')
          .attr('x1', -15)
          .attr('y1', -15)
          .attr('x2', 15)
          .attr('y2', 15)
          .attr('stroke', '#334155')
          .attr('stroke-width', 2);
        el.append('line')
          .attr('x1', 15)
          .attr('y1', -15)
          .attr('x2', -15)
          .attr('y2', 15)
          .attr('stroke', '#334155')
          .attr('stroke-width', 2);
      }
    });

    // Labels
    node.append('text')
      .text(d => d.name)
      .attr('y', 35)
      .attr('text-anchor', 'middle')
      .attr('font-size', '12px')
      .attr('fill', '#1e293b')
      .attr('font-weight', '500');

    simulation.on('tick', () => {
      link
        .attr('x1', d => (d.source as any).x)
        .attr('y1', d => (d.source as any).y)
        .attr('x2', d => (d.target as any).x)
        .attr('y2', d => (d.target as any).y);

      node
        .attr('transform', d => `translate(${d.x},${d.y})`);
    });

    function dragstarted(event: any) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      event.subject.fx = event.subject.x;
      event.subject.fy = event.subject.y;
    }

    function dragged(event: any) {
      event.subject.fx = event.x;
      event.subject.fy = event.y;
    }

    function dragended(event: any) {
      if (!event.active) simulation.alphaTarget(0);
      event.subject.fx = null;
      event.subject.fy = null;
    }

    return () => {
      simulation.stop();
    };
  }, [members, relationships]);

  return (
    <div className="w-full h-full bg-slate-50 rounded-xl border border-slate-200 overflow-hidden shadow-inner relative">
      <svg
        ref={svgRef}
        className="w-full h-full cursor-move"
        viewBox="0 0 800 600"
        id="genogram-canvas"
      />
      <div className="absolute bottom-4 right-4 bg-white/80 backdrop-blur-sm p-2 rounded-lg border border-slate-200 text-[10px] text-slate-500 flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 border border-slate-400 bg-white"></div> Male
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 border border-slate-400 bg-white rounded-full"></div> Female
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 border border-slate-400 bg-white flex items-center justify-center">X</div> Deceased
        </div>
      </div>
    </div>
  );
};

export default GenogramVisualizer;
